# Privacy Policy — 90 Days Track

_Last updated: [DATE]_

90 Days Track ("the app") is a personal study-tracking app.

**Data we collect:** None. The app does not collect, transmit, or share any personal information.

**Data stored on your device:** Your profile details, goals, notes, tasks, study sessions and progress are saved locally on your device only. We cannot access them. Uninstalling the app or clearing its storage deletes this data. You can export a backup file from the app at any time.

**Third parties:** The app has no ads, analytics, or third-party SDKs.

**Children:** The app is not directed to children under 13.

**Changes:** Updates to this policy will be posted on this page.

**Contact:** [your-email@example.com]
