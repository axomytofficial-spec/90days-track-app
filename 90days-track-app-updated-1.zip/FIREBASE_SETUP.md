# Turn on sign-in and cloud save (Firebase)

Until you do this, the app works as before with no sign-in.

1. Go to https://console.firebase.google.com and create a project.
2. Build > Authentication > Get started. Turn on **Email/Password**. Also turn on **Google** and **Facebook** if you want them (Facebook needs an App ID and Secret from developers.facebook.com).
3. Build > Firestore Database > Create database.
4. In Firestore > Rules, paste this and publish:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

5. Project settings > Your apps > add a **Web app**. Copy the config values into `www/firebase-config.js`.
6. Authentication > Settings > Authorized domains: add `localhost`.
7. Rebuild the app (`npx cap sync android`) and install it.

Notes
- Email/password sign-in works in the Android app.
- Google sign-in in the Android app is native: it shows the Google accounts already on the phone. See "Native Google sign-in" below.
- Facebook button uses a browser popup. These often fail inside an Android WebView. For reliable social sign-in in the Play Store app, add the `@capacitor-firebase/authentication` plugin.
- Guests: the sign-in screen has a Continue as guest button. Guest progress stays on that phone only (no cloud save). If a guest later signs in to an account that already has saved data, the account's data replaces the guest data on that phone.
- Instagram has no standard sign-in for apps, so it is not included.
- Each user's progress is saved to their own account document and loads again on a new phone.

## Native Google sign-in (Android app)
1. Firebase console > Project settings > Your apps > **Add app > Android**. Package name: `com.axomyt.ninetydaystrack1`. Add your **SHA-1** (debug and release; for Play Store builds also the Play App Signing SHA-1 from Play Console > App integrity). Command: `cd android && ./gradlew signingReport`.
2. Download `google-services.json` and put it in `android/app/`.
3. Make sure Google is enabled under Authentication > Sign-in method.
4. Run `npm install @capacitor-firebase/authentication@^6` and add to capacitor.config.json: `"plugins":{"FirebaseAuthentication":{"skipNativeAuth":true,"providers":["google.com"]}}`. Do this ONLY after google-services.json is in android/app/, otherwise the app crashes on launch.
5. Run `npx cap sync android`, rebuild and reinstall the app.

## Build the APK from a phone (GitHub Actions)
1. Put this whole project in a **private** GitHub repository (the file `debug.keystore` is the signing key; keep the repo private).
2. Open the repo > **Actions** > **Build Android APK** > **Run workflow**.
3. When it finishes, open the run. The step "Use fixed signing key" prints the SHA-1 to add in Firebase. The APK is under **Artifacts** (90days-track-apk).
4. After adding the SHA-1 in Firebase, download `google-services.json`, upload it to the repo root (next to package.json), and run the workflow again.
This debug key is for testing. For the Play Store use Play App Signing and add its SHA-1 as well.
