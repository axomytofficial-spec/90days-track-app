// Firebase web app config for 90 Days Track.
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyC27M2aRAUXGm8VEBpO6PvF81G_2wwf_Ng",
  authDomain: "days-track-82a19.firebaseapp.com",
  projectId: "days-track-82a19",
  storageBucket: "days-track-82a19.firebasestorage.app",
  messagingSenderId: "431236996476",
  appId: "1:431236996476:web:99bc46cb96aab2e55718f9"
};
