# 90 Days Track — Play Store build guide

## 0. Before you start
- Install Node 18+, Android Studio (includes JDK + SDK).
- Edit `appId` in `capacitor.config.json` (e.g. `com.rahul.ninetydaystrack`). **It can never change after publishing.**

## 1. Build the Android project
```
npm install
npx cap add android
npm run assets      # generates launcher icons + splash from /resources
npm run sync
npm run open        # opens Android Studio
```

## 2. Version & target SDK
In `android/app/build.gradle`: set `versionCode 1`, `versionName "1.0.0"`.
Play requires targetSdk to meet the current policy (check Play Console → App content). Capacitor 6 defaults are usually fine; bump Capacitor if Play complains.

## 3. Sign and build the .aab
Android Studio → Build → Generate Signed Bundle / APK → **Android App Bundle**.
Create a new keystore, **back it up** (lose it = can't update the app). Enroll in Play App Signing when uploading.
Output: `android/app/release/app-release.aab`

## 4. Play Console checklist
- Developer account ($25 one-time). Personal accounts: closed test with 12+ testers for 14 days before production.
- Store listing: title, short (80 chars) + full description, 512×512 icon (`www/icons/icon-512.png`), feature graphic (`resources/play-feature-graphic-1024x500.png`), 2+ phone screenshots.
- Privacy policy URL (see PRIVACY_POLICY.md — host it anywhere public, e.g. GitHub Pages).
- Data safety form: data collected = none; all data stored on device only.
- Content rating questionnaire, target audience (13+ suggested), ads declaration = no ads.

## 5. Test first
`npx cap run android` on a device/emulator. Check: add/edit/delete notes & tasks, calendar marking, timer, export/import backup, offline launch, back-button behaviour.
