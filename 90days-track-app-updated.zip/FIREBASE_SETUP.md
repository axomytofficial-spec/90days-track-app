# Turn on sign-in and cloud save (Firebase)

Until you do this, the app works as before with no sign-in.

1. Go to https://console.firebase.google.com and create a project.
2. Build > Authentication > Get started. Turn on **Email/Password**. Also turn on **Google** and **Facebook** if you want them (Facebook needs an App ID and Secret from developers.facebook.com).
3. Build > Firestore Database > Create database.
4. In Firestore > Rules, paste this and publish:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

5. Project settings > Your apps > add a **Web app**. Copy the config values into `www/firebase-config.js`.
6. Authentication > Settings > Authorized domains: add `localhost`.
7. Rebuild the app (`npx cap sync android`) and install it.

Notes
- Email/password sign-in works in the Android app.
- Google and Facebook buttons use a browser popup. These often fail inside an Android WebView. For reliable social sign-in in the Play Store app, add the `@capacitor-firebase/authentication` plugin.
- Guests: the sign-in screen has a Continue as guest button. Guest progress stays on that phone only (no cloud save). If a guest later signs in to an account that already has saved data, the account's data replaces the guest data on that phone.
- Instagram has no standard sign-in for apps, so it is not included.
- Each user's progress is saved to their own account document and loads again on a new phone.
