(function(){
'use strict';
var cfg=window.FIREBASE_CONFIG||{};
var configured=cfg.apiKey&&String(cfg.apiKey).indexOf('YOUR_')!==0;
var $=function(s){return document.querySelector(s)};
var KEY_UID='90dt_uid',KEY_DATA='90dt_data',KEY_GUEST='90dt_guest';
var acct=$('#accountCard');
if(!configured){if(acct)acct.style.display='none';return}

var css='#authGate{position:fixed;inset:0;z-index:9999;background:#f7faf7;overflow:auto;padding:calc(env(safe-area-inset-top,0px) + 28px) 22px 28px;display:none;color:#0f3d33;font-family:inherit}'
+'#authGate .box{max-width:420px;margin:0 auto}#authGate h1{margin:0;font-size:26px}#authGate .tg{color:#6b7d86;font-size:14px;margin-bottom:26px}'
+'#authGate h2{font-size:22px;margin:0 0 4px}#authGate .sb{color:#6b7d86;font-size:14px;margin-bottom:16px}'
+'#authGate input{width:100%;border:1px solid #dbe8e1;border-radius:14px;padding:14px;font-size:16px;margin-bottom:10px;background:#fff;color:#0f3d33;font-family:inherit}'
+'#authGate button{width:100%;border-radius:26px;padding:14px;font-size:16px;font-weight:600;cursor:pointer;font-family:inherit}'
+'#authGate .p{background:#247657;color:#fff;border:0}#authGate .o{background:#fff;color:#0f3d33;border:1px solid #dbe8e1;margin-top:10px}'
+'#authGate .lk{background:transparent;border:0;color:#247657;font-size:14px;padding:10px;width:auto;display:block;margin:6px auto 0;font-weight:500}'
+'#authGate .dv{text-align:center;color:#6b7d86;font-size:13px;margin:16px 0 6px}#authGate .er{color:#b3261e;font-size:14px;min-height:20px;margin:2px 0 8px}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);

var g=document.createElement('div');g.id='authGate';
g.innerHTML='<div class="box"><h1>\uD83C\uDF31 90 Days Track</h1><div class="tg">Small Steps \u2022 Big Changes</div>'
+'<h2 id="agTitle">Welcome back</h2><div class="sb" id="agSub">Sign in to save your progress to your account.</div>'
+'<input id="agEmail" type="email" placeholder="Email" autocomplete="email"><input id="agPass" type="password" placeholder="Password (6+ characters)" autocomplete="current-password">'
+'<div class="er" id="agErr" role="alert"></div><button class="p" id="agGo" type="button">Sign in</button>'
+'<button class="lk" id="agForgot" type="button">Forgot password?</button>'
+'<div class="dv">or continue with</div><button class="o" id="agGoogle" type="button">Google</button><button class="o" id="agFb" type="button">Facebook</button>'
+'<button class="lk" id="agSwitch" type="button" style="margin-top:18px">New here? Create an account</button>'
+'<button class="o" id="agGuest" type="button" style="margin-top:14px">Continue as guest</button><div class="sb" style="text-align:center;margin:8px 0 0;font-size:13px">Guest progress is saved on this phone only.</div></div>';
document.body.appendChild(g);

var mode='in';
function err(m){$('#agErr').textContent=m||''}
function setMode(m){mode=m;err('');
 $('#agTitle').textContent=m==='in'?'Welcome back':'Create your account';
 $('#agSub').textContent=m==='in'?'Sign in to save your progress to your account.':'Your progress will be saved to your account.';
 $('#agGo').textContent=m==='in'?'Sign in':'Create account';
 $('#agSwitch').textContent=m==='in'?'New here? Create an account':'Already have an account? Sign in';
 $('#agForgot').style.display=m==='in'?'block':'none';
 $('#agPass').autocomplete=m==='in'?'current-password':'new-password'}
function show(on){g.style.display=on?'block':'none'}
function isGuest(){return localStorage.getItem(KEY_GUEST)==='1'}
function acctText(t,btn){if(!acct)return;acct.querySelector('#accountEmail').textContent=t;var b=acct.querySelector('#signOutBtn');if(b&&btn)b.textContent=btn}
function nice(e){var c=e&&e.code||'';
 var map={'auth/invalid-email':'That email address doesn\u2019t look right.','auth/user-not-found':'No account found for that email.','auth/wrong-password':'Wrong password. Try again.','auth/invalid-credential':'Email or password is wrong.','auth/email-already-in-use':'That email already has an account. Sign in instead.','auth/weak-password':'Use at least 6 characters for the password.','auth/network-request-failed':'No internet connection. Connect and try again.','auth/too-many-requests':'Too many tries. Wait a bit and try again.','auth/popup-closed-by-user':'Sign-in was cancelled.','auth/operation-not-supported-in-this-environment':'This sign-in method isn\u2019t available in the app yet. Use email.','auth/unauthorized-domain':'This app isn\u2019t allowed to use that sign-in yet.'};
 return map[c]||'Something went wrong. Try again.'}

if(!window.firebase){
 // SDK could not load (offline). Let previously signed-in users in; others must connect first.
 if(localStorage.getItem(KEY_UID)||isGuest()){acctText(isGuest()?'Guest (this phone only)':'Offline');return}
 setMode('in');show(true);err('Connect to the internet to sign in the first time.');return}

firebase.initializeApp(cfg);
var auth=firebase.auth(),db=firebase.firestore();
setMode('in');

$('#agGuest').onclick=function(){localStorage.setItem(KEY_GUEST,'1');show(false);acctText('Guest (this phone only)','Sign in to save online')};
$('#agSwitch').onclick=function(){setMode(mode==='in'?'up':'in')};
$('#agGo').onclick=function(){
 var em=$('#agEmail').value.trim(),pw=$('#agPass').value;
 if(!em||!pw){err('Enter your email and password.');return}
 err('');var b=$('#agGo');b.disabled=true;
 var p=mode==='in'?auth.signInWithEmailAndPassword(em,pw):auth.createUserWithEmailAndPassword(em,pw);
 p.catch(function(e){err(nice(e))}).then(function(){b.disabled=false})};
$('#agForgot').onclick=function(){var em=$('#agEmail').value.trim();if(!em){err('Enter your email first, then tap Forgot password.');return}
 auth.sendPasswordResetEmail(em).then(function(){err('');alert('Password reset email sent. Check your inbox.')}).catch(function(e){err(nice(e))})};
function social(pr){err('');auth.signInWithPopup(pr).catch(function(e){err(nice(e))})}
$('#agGoogle').onclick=function(){social(new firebase.auth.GoogleAuthProvider())};
$('#agFb').onclick=function(){social(new firebase.auth.FacebookAuthProvider())};

var t;
function push(){clearTimeout(t);t=setTimeout(pushNow,1500)}
function pushNow(){var u=auth.currentUser;if(!u||!window.__app)return Promise.resolve();
 return db.collection('users').doc(u.uid).set({json:JSON.stringify(window.__app.getData()),updatedAt:firebase.firestore.FieldValue.serverTimestamp()}).catch(function(){})}
window.__onSave=function(){if(auth.currentUser)push()};

function sync(user){
 var prev=localStorage.getItem(KEY_UID),same=prev===user.uid;
 return db.collection('users').doc(user.uid).get().then(function(snap){
  var local=window.__app?window.__app.getData():{},lt=local._updatedAt||0;
  var cloud=snap.exists&&snap.data().json?JSON.parse(snap.data().json):null;
  if(cloud){
   if(!same||(cloud._updatedAt||0)>lt){localStorage.setItem(KEY_DATA,JSON.stringify(cloud));localStorage.setItem(KEY_UID,user.uid);location.reload();return}
   if(lt>(cloud._updatedAt||0))pushNow();
  }else{
   if(prev&&!same){localStorage.removeItem(KEY_DATA);localStorage.setItem(KEY_UID,user.uid);location.reload();return}
   pushNow();
  }
  localStorage.setItem(KEY_UID,user.uid)
 }).catch(function(){localStorage.setItem(KEY_UID,user.uid)})}

auth.onAuthStateChanged(function(user){
 if(!user){if(isGuest()){show(false);acctText('Guest (this phone only)','Sign in to save online')}else{show(true);acctText('Not signed in','Sign out')}return}
 localStorage.removeItem(KEY_GUEST);show(false);
 acctText(user.email||user.displayName||'Signed in','Sign out');
 sync(user)});

var so=$('#signOutBtn');
if(so)so.onclick=function(){if(!auth.currentUser){show(true);err('');return}if(!confirm('Sign out? Your progress stays saved in your account.'))return;
 pushNow().then(function(){return auth.signOut()}).then(function(){localStorage.removeItem(KEY_DATA);localStorage.removeItem(KEY_UID);location.reload()})};
})();
